<?php die(); ?>
a:5:{s:5:"%site";a:55:{s:4:"skin";s:7:"default";s:17:"frontend_encoding";s:5:"UTF-8";s:7:"useutf8";i:1;s:8:"utf8html";i:1;s:7:"wysiwyg";i:0;s:19:"news_title_max_long";i:100;s:11:"date_adjust";i:0;s:7:"smilies";s:50:"smile,wink,wassat,tongue,laughing,sad,angry,crying";s:18:"allow_registration";i:1;s:18:"registration_level";i:4;s:12:"ban_attempts";i:3;s:18:"allowed_extensions";s:24:"gif,jpg,png,bmp,jpe,jpeg";s:14:"reverse_active";i:0;s:10:"full_popup";i:0;s:17:"full_popup_string";s:49:"HEIGHT=400,WIDTH=650,resizable=yes,scrollbars=yes";s:23:"show_comments_with_full";i:1;s:16:"timestamp_active";s:5:"d M Y";s:11:"use_captcha";i:1;s:18:"reverse_c  omments";i:0;s:10:"flood_time";i:15;s:16:"comment_max_long";i:1500;s:17:"comments_per_page";i:5;s:23:"only_registered_comment";i:0;s:22:"allow_url_instead_mail";i:1;s:14:"comments_popup";i:0;s:21:"comments_popup_string";s:49:"HEIGHT=400,WIDTH=650,resizable=yes,scrollbars=yes";s:23:"show_full_with_comments";i:1;s:17:"timestamp_comment";s:11:"d M Y h:i a";s:8:"mon_list";s:85:"January,February,March,April,May,June,July,August,September,October,November,December";s:9:"week_list";s:56:"Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday";s:15:"active_news_def";i:20;s:21:"thumbnail_with_upload";i:0;s:19:"notify_registration";i:0;s:14:"notify_comment";i:0;s:17:"notify_unapproved";i:0;s:14:"notify_archive";i:0;s:16:"notify_postponed";i:0;s:4:"i18n";s:5:"en_US";s:11:"gplus_width";i:350;s:11:"fb_comments";i:3;s:12:"fb_box_width";i:550;s:6:"ck_ln1";s:120:"Source,Maximize,Scayt,PasteText,Undo,Redo,Find,Replace,-,SelectAll,RemoveFormat,NumberedList,BulletedList,Outdent,Indent";s:6:"ck_ln2";s:33:"Image,Table,HorizontalRule,Smiley";s:6:"ck_ln3";s:18:"Link,Unlink,Anchor";s:6:"ck_ln4";s:33:"Format,FontSize,TextColor,BGColor";s:6:"ck_ln5";s:39:"Bold,Italic,Underline,Strike,Blockquote";s:6:"ck_ln6";s:51:"JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock";s:6:"ck_ln7";s:0:"";s:6:"ck_ln8";s:0:"";s:11:"rw_htaccess";s:0:"";s:9:"rw_prefix";s:6:"/news/";s:15:"http_script_dir";s:29:"http://192.168.1.127/cutenews";s:11:"uploads_dir";s:39:"D:\tools\WebServ\httpd\cutenews/uploads";s:11:"uploads_ext";s:37:"http://192.168.1.127/cutenews/uploads";s:9:"rw_layout";s:43:"D:\tools\WebServ\httpd\cutenews/example.php";}s:3:"grp";a:5:{i:1;a:4:{s:1:"N";s:5:"admin";s:1:"G";s:1:"*";s:1:"#";b:1;s:1:"A";s:160:"Cd,Cvm,Csc,Cp,Cc,Ct,Ciw,Cmm,Cum,Cg,Cb,Ca,Cbi,Caf,Crw,Csl,Cwp,Cmt,Cpc,Can,Cvn,Ccv,Cen,Clc,Csr,Com,Nes,Neg,Nea,Nvs,Nvg,Nva,Nua,Nud,Ncd,Mes,Meg,Mea,Mds,Mdg,Mda,Mac";}i:2;a:4:{s:1:"N";s:6:"editor";s:1:"G";s:1:"3";s:1:"#";b:1;s:1:"A";s:77:"Cd,Cp,Cmm,Can,Cvn,Nes,Neg,Nea,Nvs,Nvg,Nva,Mes,Meg,Mea,Mds,Mdg,Mda,Mac,Nua,Ncd";}i:3;a:4:{s:1:"N";s:10:"journalist";s:1:"G";s:0:"";s:1:"#";b:1;s:1:"A";s:60:"Cd,Cp,Cmm,Can,Cvn,Nes,Neg,Nvs,Nvg,Mes,Meg,Mds,Mdg,Mac,Bd,Ncd";}i:4;a:4:{s:1:"N";s:9:"commenter";s:1:"G";s:0:"";s:1:"#";b:1;s:1:"A";s:33:"Cd,Cp,Nes,Nvs,Mes,Nes,Mes,Mds,Mac";}i:5;a:4:{s:1:"N";s:3:"ban";s:1:"G";s:0:"";s:1:"#";b:1;s:1:"A";s:7:"Nvs,Cvn";}}s:10:"crypt_salt";s:64:"1cefc8b01b5dbf5029bbdb49e40927f2244542ee47ff49ba2c5f2073bfa0de41";s:15:"templates_basic";a:2:{s:4:"hash";s:32:"a78a1938470a7ba5bba6db7476b5e22e";s:9:"templates";a:4:{s:7:"default";a:9:{s:6:"active";s:768:"<div style="width: 100%; margin-bottom:30px;">
    <div style="clear:both;">
         
       <div style="word-wrap:break-word; width:300px; float:left;"><strong>[link]{title}[/link]</strong></div>
        <div style="text-align:right;">[print]printable version[/print]</div>      
    </div>
    <div style="text-align:justify; padding:3px; margin-top:3px; margin-bottom:5px; border-top:1px solid #D3D3D3;">{short-story}
        <div style="margin-top:10px;">[full-link target=_blank]Read more... [/full-link]</div>
    </div>
    <div style="margin: 0 0 8px 0;">{tagline}</div>
    <div style="float: right;">[com-link]{comments-num} Comments[/com-link]</div>
    <div><em>Posted on {date} by {author}</em></div>
    {fb-comments} {fb-like} {gplus} {twitter}
</div>
";s:4:"full";s:388:"<div style="width: 100%; margin-bottom:15px;">
    <div><strong>{title}</strong></div>
    <div style="text-align:justify; padding:3px; margin-top:3px; margin-bottom:5px; border-top:1px solid #D3D3D3;">{full-story}</div>
    <div style="float: right;">{comments-num} Comments</div>
    <div><em>Posted on {date} by {author}</em></div>
    {fb-comments} {fb-like} {gplus} {twitter}
</div>
";s:7:"comment";s:309:"<div style="width: 100%; margin-bottom:20px;">
   <div style="border-bottom:1px solid black;">[delete]%cbox[/delete] by <strong>{author}</strong> @ {date} [edited](<i>Edited: %edited</i>)[/edited] [edit][Edit comment][/edit]</div>
   <div style="padding: 2px; background-color:#F9F9F9">{comment}</div>
</div>
";s:4:"form";s:455:"<table border="0" width="370" cellspacing="0" cellpadding="0">
   <tr><td width="60">Name:</td><td>{input_username} {remember_me}</td></tr>
   <tr><td>E-mail:</td><td>{input_email} (optional)</td></tr>
   <tr><td>Smile:</td><td>{smilies}</td></tr>
   <tr><td colspan="2">{input_commentbox}</td></tr>
   [captcha]<tr><td>Captcha</td><td>{captcha}</td></tr>[/captcha]    
   <tr><td colspan="2" align="right">[submit]Add comment[/submit]</td></tr>
</table>
";s:9:"prev_next";s:96:"<p align="center">[prev-link]<< Previous[/prev-link] {pages} [next-link]Next >>[/next-link]</p>
";s:18:"comments_prev_next";s:97:"<p align="center">[prev-link]<< Older[/prev-link] ({pages}) [next-link]Newest >>[/next-link]</p>
";s:6:"search";s:301:"<form action="{php_self}" method="GET" class="cn_search_form">
 <div>{search_basic} Author: {author} {in_archives} In archives</div>
 <div>{select=year:from} {select=mon:from} {select=day:from} &ndash; {select=year:to} {select=mon:to} {select=day:to}</div>
 <div>[submit]Search[/submit]</div>
</form>
";s:7:"tagline";s:102:"<a href="{url}" target="_blank" class="cn_tag_item{tag:selected| cn_tag_selected}">{tag}</a>{comma| }
";s:5:"print";s:313:"<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body bgcolor="#ffffff" text="#000000" onload="window.print()">
<strong>{title} @ <small>{date}</small></strong></div>
<hr/>{full-story}<hr/>
<small>News powered by CuteNews - http://cutephp.com</small>
</body></html>
";}s:9:"headlines";a:9:{s:6:"active";s:67:"[full-link]{title}[/full-link], posted on {date} by {author}<br />
";s:4:"full";s:326:"<div style="width:420px; margin-bottom:15px;">
<div><strong>{title}</strong></div>
<div style="text-align:justify; padding:3px; margin-top:3px; margin-bottom:5px; border-top:1px solid #D3D3D3;">{full-story}</div>
<div style="float: right;">{comments-num} Comments</div>
<div><em>Posted on {date} by {author}</em></div>
</div>
";s:7:"comment";s:309:"<div style="width: 100%; margin-bottom:20px;">
   <div style="border-bottom:1px solid black;">[delete]%cbox[/delete] by <strong>{author}</strong> @ {date} [edited](<i>Edited: %edited</i>)[/edited] [edit][Edit comment][/edit]</div>
   <div style="padding: 2px; background-color:#F9F9F9">{comment}</div>
</div>
";s:4:"form";s:425:"<table border="0" width="370" cellspacing="0" cellpadding="0">
   <tr><td width="60">Name:</td><td>{input_username} {remember_me}</td></tr>
   <tr><td>E-mail:</td><td>{input_email} (optional)</td></tr>
   <tr><td>Smile:</td><td>{smilies}</td></tr>
   [captcha]<tr><td>Captcha</td><td>{captcha}</td></tr>[/captcha]
   <tr><td colspan="2">{input_commentbox}</td></tr>
   <tr><td>[submit]Add comment[/submit]</td></tr>
</table>
";s:9:"prev_next";s:0:"";s:18:"comments_prev_next";s:0:"";s:6:"search";s:301:"<form action="{php_self}" method="GET" class="cn_search_form">
 <div>{search_basic} Author: {author} {in_archives} In archives</div>
 <div>{select=year:from} {select=mon:from} {select=day:from} &ndash; {select=year:to} {select=mon:to} {select=day:to}</div>
 <div>[submit]Search[/submit]</div>
</form>
";s:5:"print";s:0:"";s:7:"tagline";s:102:"<a href="{url}" target="_blank" class="cn_tag_item{tag:selected| cn_tag_selected}">{tag}</a>{comma| }
";}s:3:"rss";a:1:{s:6:"active";s:223:"<item>
   <title><![CDATA[{title}]]></title>
   <link>{rss-news-include-url}</link>
   <description><![CDATA[{short-story}]]></description>
   <guid isPermaLink="false">{news-id}</guid>
   <pubDate>{date}</pubDate>
</item>
";}s:4:"mail";a:3:{s:15:"password_change";s:112:"Dear %username%!
Your password has been changed. Authorisation data:
  Login: %username%
  Password: %password%
";s:23:"resend_activate_account";s:101:"Dear %username%!
Click to this activation link %url% for restore your account. Secret word: %secret%
";s:17:"notify_unapproved";s:98:"The user %username% (journalist) posted article '%article_title%' which needs first to be Approved";}}}s:9:"templates";a:1:{s:7:"default";a:9:{s:6:"active";s:654:"<div style="width: 100%; margin-bottom:30px;">
    <div style="clear:both;">
         
       <div style="word-wrap:break-word; width:300px; float:left;">{title}</div>
<br><br>
        <div style="text-align:right;"></div>      
    </div>
    <div style="text-align:justify; padding:3px; margin-top:3px; margin-bottom:5px; border-top:1px solid #D3D3D3; font-size: 12px;">{short-story}
        <div style="margin-top:10px;">[full-link target=_blank]Read more... [/full-link]</div>
    </div>
    <div style="margin: 0 0 8px 0;">{tagline}</div>
    <div style="float: right;"></div>
   
    {fb-comments} {fb-like} {gplus} {twitter}
</div>
";s:4:"full";s:388:"<div style="width: 100%; margin-bottom:15px;">
    <div><strong>{title}</strong></div>
    <div style="text-align:justify; padding:3px; margin-top:3px; margin-bottom:5px; border-top:1px solid #D3D3D3;">{full-story}</div>
    <div style="float: right;">{comments-num} Comments</div>
    <div><em>Posted on {date} by {author}</em></div>
    {fb-comments} {fb-like} {gplus} {twitter}
</div>
";s:7:"comment";s:309:"<div style="width: 100%; margin-bottom:20px;">
   <div style="border-bottom:1px solid black;">[delete]%cbox[/delete] by <strong>{author}</strong> @ {date} [edited](<i>Edited: %edited</i>)[/edited] [edit][Edit comment][/edit]</div>
   <div style="padding: 2px; background-color:#F9F9F9">{comment}</div>
</div>
";s:4:"form";s:455:"<table border="0" width="370" cellspacing="0" cellpadding="0">
   <tr><td width="60">Name:</td><td>{input_username} {remember_me}</td></tr>
   <tr><td>E-mail:</td><td>{input_email} (optional)</td></tr>
   <tr><td>Smile:</td><td>{smilies}</td></tr>
   <tr><td colspan="2">{input_commentbox}</td></tr>
   [captcha]<tr><td>Captcha</td><td>{captcha}</td></tr>[/captcha]    
   <tr><td colspan="2" align="right">[submit]Add comment[/submit]</td></tr>
</table>
";s:9:"prev_next";s:96:"<p align="center">[prev-link]<< Previous[/prev-link] {pages} [next-link]Next >>[/next-link]</p>
";s:18:"comments_prev_next";s:97:"<p align="center">[prev-link]<< Older[/prev-link] ({pages}) [next-link]Newest >>[/next-link]</p>
";s:6:"search";s:301:"<form action="{php_self}" method="GET" class="cn_search_form">
 <div>{search_basic} Author: {author} {in_archives} In archives</div>
 <div>{select=year:from} {select=mon:from} {select=day:from} &ndash; {select=year:to} {select=mon:to} {select=day:to}</div>
 <div>[submit]Search[/submit]</div>
</form>
";s:7:"tagline";s:102:"<a href="{url}" target="_blank" class="cn_tag_item{tag:selected| cn_tag_selected}">{tag}</a>{comma| }
";s:5:"print";s:313:"<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body bgcolor="#ffffff" text="#000000" onload="window.print()">
<strong>{title} @ <small>{date}</small></strong></div>
<hr/>{full-story}<hr/>
<small>News powered by CuteNews - http://cutephp.com</small>
</body></html>
";}}}