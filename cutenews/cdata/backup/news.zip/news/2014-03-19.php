<?php die('Direct call - access denied'); ?>
a:1:{i:1395258288;a:13:{s:2:"id";i:1395258288;s:1:"t";s:15:"Zmiany 19/03/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:284:"Nowy kanał irc #uo-pvp

- Dodano: Zwój zmiany nazwy przedmiotu. Koszt 1mln.
- Zmiana: Balans broni i łuków. Trwają testy nowych obrażen broni.
- Zmiana: Zwiększono szanse na blok tarczą.
- Zmiana: Skrócono odległość precastu.
- Usunięto: Leczenie się maga w biegu.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}