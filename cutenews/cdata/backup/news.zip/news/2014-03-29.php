<?php die('Direct call - access denied'); ?>
a:1:{i:1396113935;a:13:{s:2:"id";i:1396113935;s:1:"t";s:15:"Zmiany 29/03/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:258:"- Dodano: Kołczan na strzały/bełty. Kołczan można wytwarzać przy pomocy umiejętności krawiectwo (robione ze skór)
- Zmiana: Oswojone stworzenia stoją w miejscu.
- Poprawiono: Zianie ogniem/mrozem oswojonych stworzeń.
- Poprawiono: Widmowy żuk.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}