<?php die('Direct call - access denied'); ?>
a:1:{i:1393748107;a:13:{s:2:"id";i:1393748107;s:1:"t";s:8:"02/03/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:407:"- Zmiana: berło i lanca ujebane, zmiany wejdą po najbliższym restarcie.
- Zmiana: czarowanie holy light i close wounds wyłączone w biegu.
- Zmiana: Zależność w szyciu skór wyjątkowej jakośći: Dla maga pod uwagę brana inteligencja, dla łucznika zręczność.
- Poprawiono: mikstury inteligencji.
- Poprawiono: przetapianie narzędzi klikając w plecak.
- Dodano: przetapianie twardej wody.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}