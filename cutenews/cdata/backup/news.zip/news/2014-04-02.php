<?php die('Direct call - access denied'); ?>
a:1:{i:1396390606;a:13:{s:2:"id";i:1396390606;s:1:"t";s:15:"Zmiany 01/04/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:328:"- Dodano: Możliwość zmiany koloru ciuchów przy pomocy kulek ulepszeń.
- Zmiana: Usher Władca Portali osłabiony.
- Poprawiono: Używanie kuli ulepszeń będzie już odpowiednio aktualizować tooltipa levelu.
- Aktualizacja: Podstrona "championy" na stronie www.
- Aktualizacja: Podstrona "Jak zacząć" na stronie www.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}