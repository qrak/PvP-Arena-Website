<?php die('Direct call - access denied'); ?>
a:1:{i:1393187026;a:13:{s:2:"id";i:1393187026;s:1:"t";s:15:"Zmiany 23/02/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:950:"- Dodano: Zbroja wodna zmniejsza otrzymywane obrazenia od ognia o 5% za każdą cześć setu (explosion, flamestrike, fireball)
- Dodano: Skóry demona, sztaby krwawnika posiadają właściwości zmniejszające obrażenia czarów nekromanckich za każdą cześć setu 3%.
- Dodano: Kula zerowania statów. Kula ta pozwala ponownie rozdzielić statystyki za pomocą komendy .staty
- Dodano: Kopalnie xilonu. Jedynie w kopalniach xilonu szansa na wykopanie tego materiału jest większa. Gracze sami muszą znaleźć tę kopalnie.
- Zmiana: Leczenie - Zmniejszono ilość kroków udanego leczenia.
- Zmiana: Łucznik - Zmniejszono dmg i prędkość łuków/kusz
- Zmiana: Magiki można ulepszać do lvl 40 (wcześniej 25)
- Zmiana: Zmniejszona ilość rudy w jednym miejscu
- Zmiana: Wrociły kolory po kulkach ulepszeń.
- Zmiana: Zbroja pierścioniowa odejmuje dexa i ma troche mniej AR
- Zmiana: Zwiekszono dmg łucznika i woja w pvm o 30%";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}