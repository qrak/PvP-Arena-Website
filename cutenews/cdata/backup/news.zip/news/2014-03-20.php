<?php die('Direct call - access denied'); ?>
a:1:{i:1395337273;a:13:{s:2:"id";i:1395337273;s:1:"t";s:15:"Zmiany 20/03/13";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:274:"- Dodano: Spawn piekielnych ogarów. Jama psów w Serpent's Hold. Psy te posiadają skóry wulkaniczne.
- Zmiana: Pełny set unikatowy daje statystyki +20 (zmiana z +40)
- Poprawiono: Bug z kulkami ulepszeń na unikatach.
- Poprawiono: Części setu mają już poziom 45.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}