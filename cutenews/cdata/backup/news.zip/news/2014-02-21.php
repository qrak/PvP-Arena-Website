<?php die('Direct call - access denied'); ?>
a:1:{i:1393022475;a:13:{s:2:"id";i:1393022475;s:1:"t";s:10:"Znowu UP?!";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:558:"
Tak jest! Po licznych prośbach graczy mamy ponownie UPa! Obecnie jesteśmy w fazie testów i kilka rzeczy może nie działać prawidłowo. Czekamy na Waszą pomoc w poprawianiu błędów. Już od wczoraj poprawiono kilka bugów dzięki garstce naszych wspaniałych graczy:
- Poprawiono pokazywanie AR w statusie.
- Poprawiono wydobywanie rudy.
- Zmniejszono psucie się zbroi/broni.
- Przyspieszono gainy STR i DEX.
- Kilka mniejszych poprawek.
Aktualne najważniejsze bugi do poprawy:
- Czasami mikstury i bless po czasie nie schodzą prawidłowo.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}