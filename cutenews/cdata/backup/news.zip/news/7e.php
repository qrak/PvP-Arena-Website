<?php die('Direct call - access denied'); ?>
a:1:{s:2:"id";a:1:{i:1393022450;s:4:"qrak";}}