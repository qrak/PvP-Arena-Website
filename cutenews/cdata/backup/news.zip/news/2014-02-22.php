<?php die('Direct call - access denied'); ?>
a:1:{i:1393039461;a:13:{s:2:"id";i:1393039461;s:1:"t";s:15:"Zmiany 22/02/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:1340:"22.02.2014

- Loch madrosc: Z powodu iz odpowiedzi na pytania krążą po internecie nagrody za loch mądrości zostają tymczasowo zmniejszone do minimum.
- Dodano: Krytyk dla lucznika: Krwawiaca strzala; przeciwnik krwawi przez dany okres czasu.
- Dodano: Krytyk dla lucznika: Paraliz; Paralizuje przeciwnika na dany okres czasu.
- Zmiana: Dodana została możliwość jednorazowego rozdania statów (.staty), przyrost statcapa z wiekiem będzie trzeba jednak ćwiczyć samodzielnie
- Zmiana: Psucie kilofu, wytrzymalosc kilofu zmniejszona znacznie.
- Zmiana: Kule ulepszen pozwalaja zmienic poziom przedmiotu do 25 (wczesniej 20), dla wyjatkow do 40 (wczesniej 20).
- Zmiana: Kule ulepszen nie zmieniaja koloru zbroi/broni.
- Zmiana: Bronie/zbroje wyjatkowej jakosci maja poziom o 10 wiekszy od zwyklych, wczesniej jedynie zmienialo hp
- Zmiana: Skory, ruda maja zmienione wspolczynniki punktow AR oraz DMG, do wybadania przez graczy jakie maja statystyki obecnie.
- Poprawione: Nozyczki dzialaja poprawnie. Nie mozna ciac w pojemnikach tylko trzeba pojedynczo (tyczmczasowo).

Stare bronie/zbroje maja te same statystyki co przed zmianami. Nalezy wytworzyc nowe ze zmienionymi statystykami.

Nowe znane bugi:

- Po najechaniu kursorem na bron nie widac zmian w dmg/ar, pomocny relog lub nalezy uzywac wiedzy o broni

";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}