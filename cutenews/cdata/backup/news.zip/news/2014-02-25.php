<?php die('Direct call - access denied'); ?>
a:1:{i:1393313614;a:13:{s:2:"id";i:1393313614;s:1:"t";s:15:"Zmiany 25/02/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:433:"- Zmiana: Ilość rudy wydobytej i tej na jednym polu została zwiększona.
- Zmiana: Zwiększono HP championów i ich obrażenia.
- Zmiana: Zmniejszono obrażenia wszystkich czarów w pvp.
- Zmiana: Specjalne uderzenia woja nie zabierają many.
- Zmiana: Łodzie tymczasowo wyłączone.
- Dodano: Paraliżujące uderzenie dla woja.
- Dodano: Portale do Deluci, Hyloth.
- Dodano: Możliwość rzucania stolcem w innych graczy.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}