<?php die('Direct call - access denied'); ?>
