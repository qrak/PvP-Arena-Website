<?php die('Direct call - access denied'); ?>
a:1:{i:1393488269;a:13:{s:2:"id";i:1393488269;s:1:"t";s:15:"Zmiany 27/02/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:776:"- Dodano: Nowa rasa - Elfy. Rasę elfów wybieramy przy ekranie tworzenia postaci.
- Dodano: komenda .rasa. Pozwala zmienić rasę w trakcie rozgrywki. Koszt 10mln. Pierwszy raz za darmo.
- Dodano: Zbroje płytowe elfie, zbroje skórzane elfie. Tylko elf może je wytwarzać. Zbroje płytową elfią mogą zakładać obie rasy.
- Zmiana: Elf łucznik może zakładać zbroje skórzaną elfią. Zbroja skórzana elfia ma więcej AR od zbroi pierścieniowej oraz nie zabiera zręczności.
- Zmiana: Stolce stały się nieruchome.
- Zmiana: Czyszczenie stolców. Dwuklik na stolec i na siebie.
- Zmiana: Szansa na wskrzeszenie zwierza wynosi teraz tylko 30%
- Poprawiono: Blokowanie się NPCów atakujących gracza.
- Poprawiono: Czyjeś stolce nie rozłączają klienta.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}