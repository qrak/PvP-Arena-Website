<?php die('Direct call - access denied'); ?>
a:1:{i:1394002504;a:13:{s:2:"id";i:1394002504;s:1:"t";s:17:"Zmiany 05/03/2014";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:351:"UP na PvP nastąpi dopiero gdy zostanie naprawiony problem z sypaniem się POLa

- Poprawiono: bug ze skrzynią championa.
- Zmiana: Łuki i kusze robione do pojemnika w którym znajduje się narzędzie.
- Zmiana: Dodano minimalnie AR zbroi płytowej.
- Zmiana: Zmniejszono ilość przyznawanych statystyk czaru bless maga, proszę jarać zioło.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}