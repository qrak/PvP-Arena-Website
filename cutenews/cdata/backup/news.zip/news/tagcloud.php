<?php die('Direct call - access denied'); ?>
a:0:{}