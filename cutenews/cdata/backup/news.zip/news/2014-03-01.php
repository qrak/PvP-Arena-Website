<?php die('Direct call - access denied'); ?>
a:1:{i:1393669776;a:13:{s:2:"id";i:1393669776;s:1:"t";s:8:"01/03/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:548:"Znane są problemy z łączem/emulatorem POL. Stabilność jest najważniejsza. Pracuje nad tym cały czas /qrak

- Dodano: Zbroje skórzane zwiększają prędkość ataku broni/łuków.
- Dodano: Zbroje skórzane przyspieszają czas czarowania.
- Dodano: Mikstury inteligencji, będą działać po najbliższym restarcie.
- Dodano: Komenda .kolor - Komenda ta sluzy do blokowania koloru przedmiotu przy zmianie levelu kulkami ulepszen. Ponowne wybranie przedmiotu likwiduje blokade.
- Zmiana: Rodzaj wykopanej rudy nie zależy już od siły.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}