<?php die('Direct call - access denied'); ?>
a:1:{s:5:"email";a:1:{s:17:"fakencziken@wp.pl";s:4:"qrak";}}