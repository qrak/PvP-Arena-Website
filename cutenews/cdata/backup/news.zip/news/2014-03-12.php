<?php die('Direct call - access denied'); ?>
a:1:{i:1394621973;a:13:{s:2:"id";i:1394621973;s:1:"t";s:15:"Zmiany 12/03/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:320:"- Zmieniono: Prędkość powtarzalnej kuszy zmniejszona
- Zmieniono: Zwiększono dmg czarów maga.
- Zmieniono: Zmniejszono nieznacznie dmg wszystkich broni
- Zmieniono: Komenda ".rasa". Jeżeli gracz jest wojownikiem i elfem to zmiana rasy nic nie kosztuje
- Zmieniono: Elf może zakładać jedynie łuki i sztylet.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}