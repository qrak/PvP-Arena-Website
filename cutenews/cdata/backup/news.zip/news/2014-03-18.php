<?php die('Direct call - access denied'); ?>
a:1:{i:1395171207;a:13:{s:2:"id";i:1395171207;s:1:"t";s:15:"Zmiany 18/03/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:391:"- Dodano: Skóra wulkaniczna - zmniejsza obrażenia od czarów ognistych (pvp/pvm)
- Dodano: Łuki do przedmiotów unikatowych
- Zmiana: Zmniejszono minimalnie dmg broni w pvp/pvm
- Zmiana: Unikaty z championów drop rate z 50% na 100%
- Poprawiono: Skóry z npców będą wypadać poprawnie.
- Poprawiono: Skóry/sztaby z championów będą dawać poziom przedmiotu 35 a wyjątki 45.
";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}