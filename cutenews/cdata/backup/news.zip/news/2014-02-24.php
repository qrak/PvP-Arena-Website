<?php die('Direct call - access denied'); ?>
a:1:{i:1393211225;a:13:{s:2:"id";i:1393211225;s:1:"t";s:15:"Zmiany 24/02/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:411:"- Dodano: Event słabiaka.
- Dodano: Sranie dla biernych makrowników. Obecnie sra każdy, nie tylko bierni. Do poprawy.
- Zmiana: Ceny u jamajczyka drastycznie spadły.
- Zmiana: Palenie marihuany daje blessa +30.
- Zmiana: Przedmioty rzadkie (ideału itp.) oraz sety mają poziom wynoszący 45.
- Zmiana: Zmniejszono ilość wypadanych rzadkich przedmiotów.
- Poprawiono: Można już sadzić marihuane.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}