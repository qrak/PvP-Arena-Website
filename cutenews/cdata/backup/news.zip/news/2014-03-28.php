<?php die('Direct call - access denied'); ?>
a:1:{i:1395991753;a:13:{s:2:"id";i:1395991753;s:1:"t";s:15:"Zmiany 28/03/14";s:1:"u";s:4:"qrak";s:1:"c";N;s:1:"s";s:471:"- Dodano: Automatyczne tworzenie konta przy wpisaniu loginu i hasła.
- Dodano: Skrypt na multiaccount. Nie można się logować z tego samego ip na dwa różne konta. Jeżeli dwie różne osoby grają na tym samym IP należy zgłosić to do GMa.
- Zmiana: Zmniejszono HP championów z 60000 na 40000.
- Zmiana: Zwiększono loot talizmanów. Talizmany będą wypadać również ze słabszych potworów.
- Aktualizacja: Dział "Jak zacząć?" w ciągłej aktualizacji.";s:1:"f";s:0:"";s:2:"ht";b:0;s:2:"st";s:0:"";s:2:"co";a:0:{}s:2:"cc";b:0;s:2:"tg";s:0:"";s:2:"pg";s:0:"";s:2:"mf";a:0:{}}}